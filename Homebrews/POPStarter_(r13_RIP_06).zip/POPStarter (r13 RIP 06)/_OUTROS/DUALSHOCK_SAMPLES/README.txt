====INSTALLATION====

Copy ds4ps2.irx and ds4ps3.irx to the root of your usb flash drive.

Load the .elf with an ELF loader (uLaunchELF for example).
That's it :D



====AUTHOR====

Made by xerpi


====POPSTARTER====
Je renommerais ds3ps2.irx en MODULE_0.IRX et je le copierais dans le
dossier POPS de la partition __common.
