--PPF Bunch pack for POPStarter r13--

Hi ! 

I am a bunch of .PFF files. You can use me to enable POPStarter advanced settings. You need a PPF patcher (such as PPF-O-Matic) to use me and apply PPF over POPStarter.ELF. 

Here is what I can do for you :

- File name : description (notes) 

- NO_LC_CRACKS.PPF : Disables the built-in LC cracks of POPStarter r13 (from WIP05. Automated modes are disabled also).
- DEBUG_AND_HALT.PPF : Prints the screen debug messages and halt (from WIP05).
- NO_VMC.PPF : Disables VMC feature (new)
- ONLY_1ST_VMC.PPF : Only the first VMC in the first virtual slot is created (new)
- NO_PAL.PPF : Disables the automatic PAL patch (new)
- FORCE_MODEX.PPF : Mode X hardcoded into POPStarter r13 (new)
- DEFAULT_IGR_TEXTURES.PPF : Disables the IGR textures loader (new)
- LC_ONLY.PPF : Enable the other subroutines (like LibCrypt cracks), disable the compatibility modes. (new).
- NO_AUTO_PATCH.PPF : Disables everything (modes, LC cracks...) (new).

POPStarter Wiki : https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/Home

ShaolinAssassin
v. 1, 04/21/2016
